console.log("1: Starting...");
require("./fibonacci");
console.log("2:End");
